export const BASIC_API_URL = 'https://d40312e1.ngrok.io';
