import FooterContainer from './FooterContainer';

export default FooterContainer;