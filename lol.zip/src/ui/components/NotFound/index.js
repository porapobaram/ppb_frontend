import { NotFoundContainer } from './NotFoundContainer';

export default NotFoundContainer;
