import React from 'react';

const NotFoundComponent = () => {
	return (
		<div>
			<h1>NOT FOUND</h1>
		</div>
	);
};

export { NotFoundComponent };
