import FbLoginButton from './FbLoginButton'

export default FbLoginButton